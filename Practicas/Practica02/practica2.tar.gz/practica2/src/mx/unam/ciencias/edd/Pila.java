package mx.unam.ciencias.edd;

/**
 * Clase para pilas genéricas.
 */
public class Pila<T> extends MeteSaca<T> {

    /**
     * Construye una pila vacía.
     */
    public Pila() {
        // Aquí va su código.
    }

    /**
     * Elimina el elemento en el tope de la pila y lo regresa.
     * @return el elemento en el tope de la pila.
     */
    @Override public T saca() {
        // Aquí va su código.
    }

    /**
     * Nos permite ver el elemento en el tope de la pila, sin
     * sacarlo de la misma.
     */
    @Override public T mira() {
        // Aquí va su código.
    }
}
